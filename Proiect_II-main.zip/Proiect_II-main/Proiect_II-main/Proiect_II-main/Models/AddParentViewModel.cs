﻿namespace Adopta_O_Emotie_Virtuala.Models
{
    public class AddParentViewModel
    {
        public String ID_User { get; set; }
        public String ExperienceWithAnimals { get; set; }
        public String Prefrences { get; set; }
    }
}
