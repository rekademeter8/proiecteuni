﻿namespace Adopta_O_Emotie_Virtuala.Models
{
    public class Ad_login
    {
        public String Admin_id { get; set; }
        public String Password { get; set;}
    }
}
