﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Adopta_O_Emotie_Virtuala.Models.DomainModels
{
    public class Foster_parents
    {
        [Key]
        public Guid ID_Parent { get; set; }

        [ForeignKey("User")]
        [Required]
        public String ID_User { get; set; }
        [Required]
        public String ExperienceWithAnimals { get; set; }
        [Required]
        public String Prefrences { get; set; }
    }
}
