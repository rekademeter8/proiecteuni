﻿using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace Adopta_O_Emotie_Virtuala.Models.DomainModels
{
    public class NoDigitsAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value != null)
            {
                string name = value.ToString();
                if (Regex.IsMatch(name, @"\d"))
                {
                    return new ValidationResult("Numele nu poate conține cifre.");
                }
            }
            return ValidationResult.Success;
        }
    }

    public class PhoneNumberAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value != null)
            {
                string phone = value.ToString();
                if (!Regex.IsMatch(phone, @"^\d{10}$"))
                {
                    return new ValidationResult("Numărul de telefon trebuie să conțină exact 10 cifre și să nu conțină litere.");
                }
            }
            return ValidationResult.Success;
        }
    }
    public class User
    {
        [Key]
        public Guid Id { get; set; }
        [Required]
        [NoDigits]
        public string Name { get; set; }
        public string Email { get; set; }
        [PhoneNumber]
        public string Phone { get; set; }
        public string Address { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Password { get; set; }

    }
}
