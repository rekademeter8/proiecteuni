﻿using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace Adopta_O_Emotie_Virtuala.Models.DomainModels
{
  
    public class Animal
    {
        [Key]
        public Guid ID_Animal { get; set; }
        [Required]
        [NoDigits]
        public string Name { get; set; }
        [Required]
        public string Species { get; set; }
        [Required]
        public string Race { get; set; }
        [Required]
        public string Size { get; set; }
        [Required]
        public string Sex { get; set; }
        [Required]
        public int Age { get; set; }
        [Required]
        public string Description { get; set; }
        [Required]
        public string Disponibiity { get; set; }
    }
}
