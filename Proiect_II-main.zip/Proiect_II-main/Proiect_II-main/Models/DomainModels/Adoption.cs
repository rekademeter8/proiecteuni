﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Adopta_O_Emotie_Virtuala.Models.DomainModels
{
    public class Adoption
    {
        [Key]
        public Guid ID_Adoption { get; set; }
        [ForeignKey("Animal")]
        [Required]
        public String ID_Animal { get; set; }
        [ForeignKey("Foster_parents")]
        [Required]
        public String ID_Parent { get; set; }
        [Required]
        public DateTime DateOfAdoption { get; set; }
        [Required]
        public String Status { get; set; }
    }
}
