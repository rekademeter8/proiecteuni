﻿namespace Adopta_O_Emotie_Virtuala.Models
{
    public class LoginViewModel
    {
        public string Email { get; set; }
    public string Password { get; set; }
    }
}
