﻿using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Microsoft.Data.SqlClient;
using Adopta_O_Emotie_Virtuala.Models;
namespace Adopta_O_Emotie_Virtuala.Models
{
    public class db
    {
        SqlConnection con = new SqlConnection("Data Source=IZABELA\\SQLEXPRESS;Initial Catalog=Adopta_O_Emotie_Virtuala;Integrated Security=True");
        public int LoginCheck(Ad_login ad)
        {
            SqlCommand com = new SqlCommand("Sp_Login", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("Admin_id", ad.Admin_id);
            com.Parameters.AddWithValue("Password", ad.Password);
            SqlParameter oblogin = new SqlParameter();
            oblogin.ParameterName = "@Isvalid";
            oblogin.SqlDbType = SqlDbType.Bit;
            oblogin.Direction = ParameterDirection.Output;
            com.Parameters.Add(oblogin);
            int res = Convert.ToInt32(oblogin.Value);
            con.Open();
            com.ExecuteNonQuery();
            con.Close();
            return res;

        }
    }
}
