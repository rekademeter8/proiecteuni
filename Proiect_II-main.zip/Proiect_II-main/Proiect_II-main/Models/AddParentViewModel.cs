﻿using System.ComponentModel.DataAnnotations;

namespace Adopta_O_Emotie_Virtuala.Models
{
    public class AddParentViewModel
    {
        [Required]
        public String ID_User { get; set; }
        [Required]
        public String ExperienceWithAnimals { get; set; }
        [Required]
        public String Prefrences { get; set; }
    }
}
