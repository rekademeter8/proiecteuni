﻿using Adopta_O_Emotie_Virtuala.Models.DomainModels;
using System;
using System.Text.RegularExpressions;
using System.ComponentModel.DataAnnotations;

namespace Adopta_O_Emotie_Virtuala.Models
{
    public class AddUserViewModel
    {
        [Required]
        [NoDigits]
        public string Name { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [PhoneNumber]
        public string Phone { get; set; }

        [Required]
        public string Address { get; set; }

        [Required]
        public DateTime DateOfBirth { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
