﻿using Adopta_O_Emotie_Virtuala.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace Adopta_O_Emotie_Virtuala.Controllers
{
    public class LoginController : Controller
    {
        db dbop = new db();
     [HttpPost]
      public IActionResult Login([Bind] Ad_login ad)
        {
            int res=dbop.LoginCheck(ad);
            if (res == 1)
            {
                TempData["msg"] = "You are welcome";
            }
            else
            {
                TempData["msg"] = "Id or password is wrong";

            }
            return View();
        }
    }
}
